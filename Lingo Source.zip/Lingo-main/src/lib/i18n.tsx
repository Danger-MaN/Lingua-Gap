// نظام تعدد اللغات البسيط (عربي/إنجليزي) عبر React Context
// يحفظ الاختيار في localStorage ويغيّر اتجاه الصفحة (RTL/LTR) تلقائياً.
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type UILang = "ar" | "en";

type Dict = Record<string, string>;

const translations: Record<UILang, Dict> = {
  ar: {
    "app.name": "Lingo",
    "nav.home": "الرئيسية",
    "stat.mastery": "الإتقان",
    "stat.learned": "كلمات متقنة",
    "stat.streak": "أعلى سلسلة",
    "bulk.title": "إضافة عدة كلمات دفعة واحدة",
    "bulk.terms": "الكلمات (بلغة الهدف) — كلمة في كل سطر",
    "bulk.translations": "الترجمات — ترجمة في كل سطر بنفس الترتيب",
    "bulk.tab.single": "كلمة واحدة",
    "bulk.tab.bulk": "عدة كلمات",
    "bulk.mismatch": "عدد الكلمات لا يطابق عدد الترجمات ({a} مقابل {b})",
    "bulk.added": "تمت إضافة {n} كلمة",
    "bulk.empty": "أدخل كلمات وترجمات أولاً",
    "drag.hint": "اضغط على الإجابة الصحيحة، أو اسحبها فوق الكلمة. يمكنك سحب الكلمة أيضاً نحو إجابتها.",
    "hero.title1": "تعلّم اللغات",
    "hero.title2": "بأسلوب اللعب 🎮",
    "hero.subtitle": "أضف كلماتك، استمع لنطقها، والعب لتثبّتها في ذاكرتك.",
    "stat.words": "كلمة",
    "stat.correct": "إجابة صحيحة",
    "stat.accuracy": "الدقة",
    "game.choice.title": "اختيار من متعدد",
    "game.choice.sub": "اختر الترجمة الصحيحة",
    "game.drag.title": "السحب والإفلات",
    "game.drag.sub": "اسحب الإجابة إلى مكانها",
    "lib.title": "قاموسي الشخصي",
    "lib.manage": "إدارة",
    "lib.count": "لديك {n} كلمة محفوظة محلياً على جهازك.",
    "lib.empty": "لا توجد كلمات بعد. ابدأ بإضافة كلمتك الأولى ✨",
    "btn.add": "إضافة كلمة",
    "btn.cancel": "إلغاء",
    "btn.save": "حفظ",
    "btn.exit": "الخروج",
    "btn.replay": "العب مجدداً",
    "btn.back": "العودة",
    "dialog.addTitle": "إضافة كلمة جديدة",
    "field.term": "الكلمة (بلغة الهدف)",
    "field.translation": "الترجمة",
    "field.lang": "لغة النطق",
    "field.listen": "استمع",
    "field.edit": "تعديل",
    "field.delete": "حذف",
    "game.question": "ما معناها؟",
    "game.dropHere": "اسحب الترجمة الصحيحة إلى هنا 👇",
    "game.needWords": "تحتاج إلى كلمتين على الأقل لبدء اللعبة.",
    "game.finished": "انتهت الجولة! 🎉",
    "game.score": "حصلت على {s} من {t} ({p}%)",
    "toast.added": "تمت إضافة الكلمة 🎉",
    "toast.fillAll": "الرجاء تعبئة الكلمة والترجمة",
    "toast.saveError": "حدث خطأ أثناء الحفظ",
    "toast.deleted": "تم الحذف",
    "toast.updated": "تم التحديث",
    "toast.emptyEdit": "لا يمكن ترك الحقول فارغة",
    "toast.speakFail": "تعذّر النطق",
    "theme.toggle": "تبديل الوضع",
    "theme.light": "فاتح",
    "theme.dark": "داكن",
    "lang.toggle": "تغيير اللغة",
  },
  en: {
    "app.name": "Lingo",
    "nav.home": "Home",
    "stat.mastery": "Mastery",
    "stat.learned": "Mastered",
    "stat.streak": "Best streak",
    "bulk.title": "Add multiple words at once",
    "bulk.terms": "Words (target language) — one per line",
    "bulk.translations": "Translations — one per line, same order",
    "bulk.tab.single": "Single",
    "bulk.tab.bulk": "Bulk",
    "bulk.mismatch": "Words and translations count don't match ({a} vs {b})",
    "bulk.added": "Added {n} words",
    "bulk.empty": "Enter words and translations first",
    "drag.hint": "Tap the correct answer, or drag it onto the word. You can also drag the word to its answer.",
    "hero.title1": "Learn languages",
    "hero.title2": "the playful way 🎮",
    "hero.subtitle": "Add your words, listen to them, and play to memorize.",
    "stat.words": "Words",
    "stat.correct": "Correct",
    "stat.accuracy": "Accuracy",
    "game.choice.title": "Multiple Choice",
    "game.choice.sub": "Pick the correct translation",
    "game.drag.title": "Drag & Drop",
    "game.drag.sub": "Drag the answer into place",
    "lib.title": "My Dictionary",
    "lib.manage": "Manage",
    "lib.count": "You have {n} words saved locally on your device.",
    "lib.empty": "No words yet. Start by adding your first one ✨",
    "btn.add": "Add Word",
    "btn.cancel": "Cancel",
    "btn.save": "Save",
    "btn.exit": "Exit",
    "btn.replay": "Play Again",
    "btn.back": "Back",
    "dialog.addTitle": "Add a new word",
    "field.term": "Word (target language)",
    "field.translation": "Translation",
    "field.lang": "Speech language",
    "field.listen": "Listen",
    "field.edit": "Edit",
    "field.delete": "Delete",
    "game.question": "What does it mean?",
    "game.dropHere": "Drag the correct translation here 👇",
    "game.needWords": "You need at least two words to start the game.",
    "game.finished": "Round complete! 🎉",
    "game.score": "You scored {s} out of {t} ({p}%)",
    "toast.added": "Word added 🎉",
    "toast.fillAll": "Please fill in the word and the translation",
    "toast.saveError": "An error occurred while saving",
    "toast.deleted": "Deleted",
    "toast.updated": "Updated",
    "toast.emptyEdit": "Fields cannot be empty",
    "toast.speakFail": "Could not speak",
    "theme.toggle": "Toggle theme",
    "theme.light": "Light",
    "theme.dark": "Dark",
    "lang.toggle": "Change language",
  },
};

interface Ctx {
  lang: UILang;
  setLang: (l: UILang) => void;
  t: (key: keyof typeof translations.ar, vars?: Record<string, string | number>) => string;
}

const I18nContext = createContext<Ctx | null>(null);
const STORAGE_KEY = "lingo-ui-lang";

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<UILang>(() => {
    if (typeof window === "undefined") return "ar";
    return ((localStorage.getItem(STORAGE_KEY) as UILang) ?? "ar");
  });

  // ضبط dir/lang على عنصر <html> عند تغيير اللغة
  useEffect(() => {
    const root = document.documentElement;
    root.lang = lang;
    root.dir = lang === "ar" ? "rtl" : "ltr";
    localStorage.setItem(STORAGE_KEY, lang);
  }, [lang]);

  const value = useMemo<Ctx>(() => ({
    lang,
    setLang: setLangState,
    t: (key, vars) => {
      let s = translations[lang][key as string] ?? translations.ar[key as string] ?? String(key);
      if (vars) for (const [k, v] of Object.entries(vars)) s = s.split(`{${k}}`).join(String(v));
      return s;
    },
  }), [lang]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}
