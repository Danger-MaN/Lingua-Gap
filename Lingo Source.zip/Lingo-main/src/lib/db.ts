// طبقة قاعدة البيانات المحلية باستخدام IndexedDB (مشابهة لـ SQLite/Hive في الموبايل)
// تحفظ الكلمات بحيث لا تضيع عند إغلاق المتصفح.
import { openDB, type DBSchema, type IDBPDatabase } from "idb";

export interface Word {
  id: string;
  term: string;          // الكلمة بالأصل
  translation: string;   // الترجمة
  lang: string;          // كود لغة النطق (مثل en-US, fr-FR)
  createdAt: number;
  correctCount: number;
  wrongCount: number;
  // الإتقان: 0..5 على غرار SM-2 المبسّط — يرتفع بالإجابات الصحيحة وينخفض بالخاطئة
  mastery?: number;
  lastSeenAt?: number;
}

// مستوى الإتقان كنسبة 0..1 (يستخدم لاختيار أقل الكلمات إتقاناً في اللعبة وللإحصائيات)
export function masteryOf(w: Word): number {
  return Math.max(0, Math.min(5, w.mastery ?? 0)) / 5;
}

// وزن كل كلمة بحسب صعوبتها على المستخدم: كلما قل الإتقان زاد الوزن (احتمال الظهور)
// يضاف عامل صغير لمدة عدم الرؤية كي لا تختفي الكلمات المتقنة كلياً.
export function weightOf(w: Word): number {
  const m = masteryOf(w); // 0 صعبة .. 1 سهلة
  const base = 1 - m; // 0..1
  // الكلمات الجديدة (mastery undefined) تأخذ وزناً عالياً
  const newcomerBoost = w.mastery == null ? 0.5 : 0;
  // الكلمات التي لم تُرَ منذ فترة طويلة ترفع وزنها قليلاً
  const days = w.lastSeenAt ? (Date.now() - w.lastSeenAt) / 86400000 : 7;
  const stale = Math.min(0.5, days / 14);
  return Math.max(0.05, base * 2 + newcomerBoost + stale);
}

// اختيار عينة موزونة بدون تكرار (Weighted reservoir-like)
export function weightedSample<T>(items: T[], weights: number[], k: number): T[] {
  const pool = items.map((it, i) => ({ it, w: Math.max(0.0001, weights[i]) }));
  const out: T[] = [];
  const n = Math.min(k, pool.length);
  for (let i = 0; i < n; i++) {
    const total = pool.reduce((s, p) => s + p.w, 0);
    let r = Math.random() * total;
    let idx = 0;
    for (let j = 0; j < pool.length; j++) {
      r -= pool[j].w;
      if (r <= 0) { idx = j; break; }
    }
    out.push(pool[idx].it);
    pool.splice(idx, 1);
  }
  return out;
}

interface LingoDB extends DBSchema {
  words: {
    key: string;
    value: Word;
    indexes: { "by-createdAt": number };
  };
}

const DB_NAME = "lingo-db";
const DB_VERSION = 1;

let dbPromise: Promise<IDBPDatabase<LingoDB>> | null = null;

function getDB() {
  if (!dbPromise) {
    dbPromise = openDB<LingoDB>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        const store = db.createObjectStore("words", { keyPath: "id" });
        store.createIndex("by-createdAt", "createdAt");
      },
    });
  }
  return dbPromise;
}

export async function getAllWords(): Promise<Word[]> {
  const db = await getDB();
  const all = await db.getAllFromIndex("words", "by-createdAt");
  return all.reverse(); // الأحدث أولاً
}

export async function addWord(input: Omit<Word, "id" | "createdAt" | "correctCount" | "wrongCount">): Promise<Word> {
  const db = await getDB();
  const word: Word = {
    ...input,
    id: crypto.randomUUID(),
    createdAt: Date.now(),
    correctCount: 0,
    wrongCount: 0,
  };
  await db.add("words", word);
  return word;
}

export async function updateWord(word: Word): Promise<void> {
  const db = await getDB();
  await db.put("words", word);
}

export async function deleteWord(id: string): Promise<void> {
  const db = await getDB();
  await db.delete("words", id);
}

export async function recordAnswer(id: string, correct: boolean): Promise<void> {
  const db = await getDB();
  const w = await db.get("words", id);
  if (!w) return;
  w.correctCount += correct ? 1 : 0;
  w.wrongCount += correct ? 0 : 1;
  const cur = w.mastery ?? 0;
  // الصحيح يرفع +1، الخطأ يخفض -1 (محصور 0..5)
  w.mastery = Math.max(0, Math.min(5, cur + (correct ? 1 : -1)));
  w.lastSeenAt = Date.now();
  await db.put("words", w);
}

// إضافة عدة كلمات دفعة واحدة
export async function addWordsBatch(
  items: Array<Omit<Word, "id" | "createdAt" | "correctCount" | "wrongCount">>
): Promise<number> {
  const db = await getDB();
  const tx = db.transaction("words", "readwrite");
  let n = 0;
  for (const it of items) {
    if (!it.term?.trim() || !it.translation?.trim()) continue;
    const word: Word = {
      ...it,
      term: it.term.trim(),
      translation: it.translation.trim(),
      id: crypto.randomUUID(),
      createdAt: Date.now() + n, // ترتيب مستقر
      correctCount: 0,
      wrongCount: 0,
      mastery: 0,
    };
    await tx.store.add(word);
    n++;
  }
  await tx.done;
  return n;
}

// كلمات افتراضية للتجربة عند أول تشغيل
export async function seedIfEmpty() {
  const db = await getDB();
  const count = await db.count("words");
  if (count > 0) return;
  const samples: Array<Omit<Word, "id" | "createdAt" | "correctCount" | "wrongCount">> = [
    { term: "Hello", translation: "مرحباً", lang: "en-US" },
    { term: "Thank you", translation: "شكراً", lang: "en-US" },
    { term: "Water", translation: "ماء", lang: "en-US" },
    { term: "Book", translation: "كتاب", lang: "en-US" },
    { term: "Friend", translation: "صديق", lang: "en-US" },
    { term: "Bonjour", translation: "مرحباً", lang: "fr-FR" },
    { term: "Merci", translation: "شكراً", lang: "fr-FR" },
    { term: "Hola", translation: "مرحباً", lang: "es-ES" },
  ];
  for (const s of samples) await addWord(s);
}
