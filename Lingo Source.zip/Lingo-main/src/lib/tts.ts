// محرك النطق Text-to-Speech باستخدام Web Speech API المدمج في المتصفح
// مع معالجة الأخطاء عند عدم توفر اللغة المطلوبة.

export const SUPPORTED_LANGS: Array<{ code: string; label: string }> = [
  { code: "en-US", label: "الإنجليزية (US)" },
  { code: "en-GB", label: "الإنجليزية (UK)" },
  { code: "fr-FR", label: "الفرنسية" },
  { code: "es-ES", label: "الإسبانية" },
  { code: "de-DE", label: "الألمانية" },
  { code: "it-IT", label: "الإيطالية" },
  { code: "tr-TR", label: "التركية" },
  { code: "ja-JP", label: "اليابانية" },
  { code: "ko-KR", label: "الكورية" },
  { code: "zh-CN", label: "الصينية" },
  { code: "ru-RU", label: "الروسية" },
  { code: "pt-PT", label: "البرتغالية" },
  { code: "ar-SA", label: "العربية" },
];

let cachedVoices: SpeechSynthesisVoice[] = [];

function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      resolve([]);
      return;
    }
    const existing = window.speechSynthesis.getVoices();
    if (existing.length) {
      cachedVoices = existing;
      resolve(existing);
      return;
    }
    const handler = () => {
      cachedVoices = window.speechSynthesis.getVoices();
      resolve(cachedVoices);
    };
    window.speechSynthesis.addEventListener("voiceschanged", handler, { once: true });
    // fallback مهلة
    setTimeout(() => resolve(window.speechSynthesis.getVoices()), 1000);
  });
}

function pickVoice(lang: string, voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | undefined {
  // مطابقة كاملة ثم على أساس البادئة (en-US -> en)
  return (
    voices.find((v) => v.lang.toLowerCase() === lang.toLowerCase()) ||
    voices.find((v) => v.lang.toLowerCase().startsWith(lang.split("-")[0].toLowerCase()))
  );
}

export interface SpeakResult {
  ok: boolean;
  reason?: string;
}

export async function speak(text: string, lang: string): Promise<SpeakResult> {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    return { ok: false, reason: "متصفحك لا يدعم خاصية النطق." };
  }
  try {
    window.speechSynthesis.cancel(); // إيقاف أي نطق سابق
    const voices = cachedVoices.length ? cachedVoices : await loadVoices();
    const voice = pickVoice(lang, voices);
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = lang;
    utter.rate = 0.95;
    utter.pitch = 1;
    if (voice) utter.voice = voice;
    window.speechSynthesis.speak(utter);
    if (!voice) {
      return { ok: true, reason: `لم يتم العثور على صوت مخصص للغة (${lang}). تم استخدام الصوت الافتراضي.` };
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, reason: (err as Error)?.message ?? "خطأ غير متوقع في النطق" };
  }
}

// تحميل الأصوات مبكراً
if (typeof window !== "undefined" && "speechSynthesis" in window) {
  loadVoices();
}
