import { useEffect, useState } from "react";
import { Trash2, Volume2, Pencil, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { deleteWord, getAllWords, updateWord, type Word } from "@/lib/db";
import { speak, SUPPORTED_LANGS } from "@/lib/tts";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useI18n } from "@/lib/i18n";

interface Props {
  refreshKey: number;
  onChanged: () => void;
}

export function WordList({ refreshKey, onChanged }: Props) {
  const { t } = useI18n();
  const [words, setWords] = useState<Word[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTerm, setEditTerm] = useState("");
  const [editTrans, setEditTrans] = useState("");
  const [editLang, setEditLang] = useState("en-US");

  useEffect(() => {
    getAllWords().then(setWords);
  }, [refreshKey]);

  const handleSpeak = async (w: Word) => {
    const r = await speak(w.term, w.lang);
    if (!r.ok) toast.error(r.reason ?? t("toast.speakFail"));
    else if (r.reason) toast.warning(r.reason);
  };

  const handleDelete = async (id: string) => {
    await deleteWord(id);
    toast.success(t("toast.deleted"));
    onChanged();
  };

  const startEdit = (w: Word) => {
    setEditingId(w.id);
    setEditTerm(w.term);
    setEditTrans(w.translation);
    setEditLang(w.lang);
  };

  const saveEdit = async (w: Word) => {
    if (!editTerm.trim() || !editTrans.trim()) {
      toast.error(t("toast.emptyEdit"));
      return;
    }
    await updateWord({ ...w, term: editTerm.trim(), translation: editTrans.trim(), lang: editLang });
    setEditingId(null);
    toast.success(t("toast.updated"));
    onChanged();
  };

  if (!words.length) {
    return (
      <Card className="p-10 text-center text-muted-foreground animate-fade-in">
        {t("lib.empty")}
      </Card>
    );
  }

  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {words.map((w, i) => (
        <Card
          key={w.id}
          className="p-4 shadow-soft hover:shadow-card transition-all animate-fade-in"
          style={{ animationDelay: `${Math.min(i, 8) * 30}ms` }}
        >
          {editingId === w.id ? (
            <div className="space-y-2">
              <Input value={editTerm} onChange={(e) => setEditTerm(e.target.value)} dir="ltr" />
              <Input value={editTrans} onChange={(e) => setEditTrans(e.target.value)} />
              <Select value={editLang} onValueChange={setEditLang}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SUPPORTED_LANGS.map((l) => <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="flex justify-end gap-2 pt-1">
                <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}><X className="h-4 w-4" /></Button>
                <Button size="sm" onClick={() => saveEdit(w)} className="gradient-primary text-primary-foreground">
                  <Check className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="text-lg font-bold truncate" dir="ltr">{w.term}</div>
                <div className="text-sm text-muted-foreground truncate">{w.translation}</div>
                <div className="mt-2 flex gap-2 text-xs">
                  <span className="rounded-full bg-muted px-2 py-0.5">{w.lang}</span>
                  {w.correctCount + w.wrongCount > 0 && (
                    <span className="rounded-full bg-success/10 text-success px-2 py-0.5">
                      ✓ {w.correctCount} / ✗ {w.wrongCount}
                    </span>
                  )}
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <Button size="icon" variant="ghost" onClick={() => handleSpeak(w)} title={t("field.listen")}>
                  <Volume2 className="h-4 w-4 text-primary" />
                </Button>
                <Button size="icon" variant="ghost" onClick={() => startEdit(w)} title={t("field.edit")}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button size="icon" variant="ghost" onClick={() => handleDelete(w.id)} title={t("field.delete")}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          )}
        </Card>
      ))}
    </div>
  );
}
