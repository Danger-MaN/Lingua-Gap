import { useState } from "react";
import { Plus, Volume2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { addWord, addWordsBatch } from "@/lib/db";
import { SUPPORTED_LANGS, speak } from "@/lib/tts";
import { toast } from "sonner";
import { useI18n } from "@/lib/i18n";

interface Props { onAdded: () => void; }

export function AddWordDialog({ onAdded }: Props) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"single" | "bulk">("single");

  // single
  const [term, setTerm] = useState("");
  const [translation, setTranslation] = useState("");
  const [lang, setLang] = useState("en-US");

  // bulk
  const [bulkTerms, setBulkTerms] = useState("");
  const [bulkTrans, setBulkTrans] = useState("");

  const reset = () => {
    setTerm(""); setTranslation(""); setLang("en-US");
    setBulkTerms(""); setBulkTrans("");
    setTab("single");
  };

  const handlePreview = async () => {
    if (!term.trim()) return;
    const r = await speak(term, lang);
    if (!r.ok) toast.error(r.reason ?? t("toast.speakFail"));
    else if (r.reason) toast.warning(r.reason);
  };

  const handleSaveSingle = async () => {
    if (!term.trim() || !translation.trim()) {
      toast.error(t("toast.fillAll"));
      return;
    }
    try {
      await addWord({ term: term.trim(), translation: translation.trim(), lang });
      toast.success(t("toast.added"));
      reset();
      setOpen(false);
      onAdded();
    } catch {
      toast.error(t("toast.saveError"));
    }
  };

  const handleSaveBulk = async () => {
    const terms = bulkTerms.split("\n").map((s) => s.trim()).filter(Boolean);
    const trans = bulkTrans.split("\n").map((s) => s.trim()).filter(Boolean);
    if (!terms.length || !trans.length) {
      toast.error(t("bulk.empty"));
      return;
    }
    if (terms.length !== trans.length) {
      toast.error(t("bulk.mismatch", { a: terms.length, b: trans.length }));
      return;
    }
    try {
      const items = terms.map((tm, i) => ({ term: tm, translation: trans[i], lang }));
      const n = await addWordsBatch(items);
      toast.success(t("bulk.added", { n }));
      reset();
      setOpen(false);
      onAdded();
    } catch {
      toast.error(t("toast.saveError"));
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) reset(); }}>
      <DialogTrigger asChild>
        <Button size="lg" className="gradient-primary text-primary-foreground shadow-glow gap-2">
          <Plus className="h-5 w-5" />
          {t("btn.add")}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t("dialog.addTitle")}</DialogTitle>
        </DialogHeader>

        <Tabs value={tab} onValueChange={(v) => setTab(v as "single" | "bulk")}>
          <TabsList className="grid grid-cols-2 w-full">
            <TabsTrigger value="single">{t("bulk.tab.single")}</TabsTrigger>
            <TabsTrigger value="bulk">{t("bulk.tab.bulk")}</TabsTrigger>
          </TabsList>

          <TabsContent value="single" className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="term">{t("field.term")}</Label>
              <div className="flex gap-2">
                <Input id="term" value={term} onChange={(e) => setTerm(e.target.value)} placeholder="Hello" dir="ltr" />
                <Button type="button" variant="outline" size="icon" onClick={handlePreview} title={t("field.listen")}>
                  <Volume2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="translation">{t("field.translation")}</Label>
              <Input id="translation" value={translation} onChange={(e) => setTranslation(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>{t("field.lang")}</Label>
              <Select value={lang} onValueChange={setLang}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SUPPORTED_LANGS.map((l) => (
                    <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="bulk" className="space-y-4 py-2">
            <p className="text-xs text-muted-foreground">{t("bulk.title")}</p>
            <div className="space-y-2">
              <Label htmlFor="bulkTerms">{t("bulk.terms")}</Label>
              <Textarea
                id="bulkTerms"
                value={bulkTerms}
                onChange={(e) => setBulkTerms(e.target.value)}
                placeholder={"Hello\nThank you\nWater"}
                dir="ltr"
                rows={5}
                className="font-mono text-sm"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bulkTrans">{t("bulk.translations")}</Label>
              <Textarea
                id="bulkTrans"
                value={bulkTrans}
                onChange={(e) => setBulkTrans(e.target.value)}
                placeholder={"مرحباً\nشكراً\nماء"}
                rows={5}
                className="text-sm"
              />
            </div>
            <div className="space-y-2">
              <Label>{t("field.lang")}</Label>
              <Select value={lang} onValueChange={setLang}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {SUPPORTED_LANGS.map((l) => (
                    <SelectItem key={l.code} value={l.code}>{l.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="gap-2 sm:gap-2">
          <Button variant="outline" onClick={() => setOpen(false)}>{t("btn.cancel")}</Button>
          <Button
            onClick={tab === "single" ? handleSaveSingle : handleSaveBulk}
            className="gradient-primary text-primary-foreground"
          >
            {t("btn.save")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
