import { useEffect, useMemo, useRef, useState } from "react";
import { Volume2, RotateCcw, Trophy, X } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { getAllWords, recordAnswer, weightOf, weightedSample, type Word } from "@/lib/db";
import { speak } from "@/lib/tts";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

interface Props {
  mode: "choice" | "drag";
  onExit: () => void;
}

// خلط مصفوفة (Fisher-Yates) — يستخدم فقط لخلط الخيارات داخل الجولة
function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

interface Round {
  word: Word;
  options: string[];
  correct: string;
}

// بناء الجولات: ترتيب الكلمات موزون حسب الصعوبة (الأصعب يظهر أكثر)،
// والمشتتات تُختار من باقي الكلمات بدون تكرار.
function buildRounds(words: Word[]): Round[] {
  if (words.length < 2) return [];
  const weights = words.map(weightOf);
  const ordered = weightedSample(words, weights, words.length);
  return ordered.map((w) => {
    const seen = new Set<string>([w.translation]);
    const distractors: string[] = [];
    for (const x of shuffle(words)) {
      if (x.id === w.id) continue;
      if (seen.has(x.translation)) continue;
      seen.add(x.translation);
      distractors.push(x.translation);
      if (distractors.length >= 3) break;
    }
    return { word: w, options: shuffle([w.translation, ...distractors]), correct: w.translation };
  });
}

// حالة السحب: إما خيار (option) أو الكلمة-الهدف (target)
interface DragState {
  kind: "option" | "target";
  opt?: string; // عند سحب خيار
  startX: number;
  startY: number;
  x: number;
  y: number;
  pointerId: number;
}

export function GameScreen({ mode, onExit }: Props) {
  const { t } = useI18n();
  const [allWords, setAllWords] = useState<Word[]>([]);
  const [rounds, setRounds] = useState<Round[]>([]);
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  // عناصر مرئية في وضع السحب
  const [visible, setVisible] = useState<string[]>([]);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [hoverOpt, setHoverOpt] = useState<string | null>(null); // الخيار الذي تمر عليه الكلمة المسحوبة
  const [hoverTarget, setHoverTarget] = useState(false); // هل الخيار المسحوب فوق الكلمة
  const [flash, setFlash] = useState<"ok" | "bad" | null>(null);
  // ghost: عنصر يتلاشى في آخر مكان تم فيه الإفلات (لإحساس واقعي)
  const [absorb, setAbsorb] = useState<{ kind: "option" | "target"; label: string; lang?: string; x: number; y: number; key: number } | null>(null);
  const targetRef = useRef<HTMLDivElement | null>(null);
  const optRefs = useRef<Map<string, HTMLButtonElement>>(new Map());

  useEffect(() => {
    getAllWords().then((ws) => {
      setAllWords(ws);
      const rs = buildRounds(ws);
      setRounds(rs);
      if (rs.length) setVisible(rs[0].options);
    });
  }, []);

  const current = rounds[idx];
  const progress = useMemo(() => (rounds.length ? (idx / rounds.length) * 100 : 0), [idx, rounds.length]);

  // === نطق الكلمة فور ظهورها (auto-speak) ===
  useEffect(() => {
    if (!current) return;
    // تأخير بسيط يسمح بانتهاء انيميشن الظهور
    const id = window.setTimeout(() => {
      speak(current.word.term, current.word.lang);
    }, 250);
    return () => window.clearTimeout(id);
  }, [current?.word.id]);

  const advance = (correct: boolean) => {
    setFlash(correct ? "ok" : "bad");
    setTimeout(() => setFlash(null), 700);
    setTimeout(() => {
      if (idx + 1 >= rounds.length) {
        setFinished(true);
      } else {
        const next = idx + 1;
        setIdx(next);
        setVisible(rounds[next].options);
        setPicked(null);
      }
    }, correct ? 700 : 900);
  };

  const commitPick = async (opt: string) => {
    if (picked || !current) return;
    setPicked(opt);
    const correct = opt === current.correct;
    await recordAnswer(current.word.id, correct);
    if (correct) setScore((s) => s + 1);
    advance(correct);
  };

  // ===== سحب: يدعم سحب الخيار أو سحب الكلمة-الهدف =====
  const startDragOption = (opt: string, e: React.PointerEvent) => {
    if (picked) return;
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    setDrag({ kind: "option", opt, startX: e.clientX, startY: e.clientY, x: e.clientX, y: e.clientY, pointerId: e.pointerId });
  };
  const startDragTarget = (e: React.PointerEvent) => {
    if (picked) return;
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    setDrag({ kind: "target", startX: e.clientX, startY: e.clientY, x: e.clientX, y: e.clientY, pointerId: e.pointerId });
  };

  useEffect(() => {
    if (!drag) return;
    const onMove = (e: PointerEvent) => {
      setDrag((d) => (d ? { ...d, x: e.clientX, y: e.clientY } : d));
      if (drag.kind === "option") {
        const rect = targetRef.current?.getBoundingClientRect();
        if (rect) {
          const cx = rect.left + rect.width / 2;
          const cy = rect.top + rect.height / 2;
          const r = Math.min(rect.width, rect.height) / 2;
          setHoverTarget(Math.hypot(e.clientX - cx, e.clientY - cy) < r + 24);
        }
      } else {
        // سحب الكلمة-الهدف فوق أحد الخيارات
        let found: string | null = null;
        optRefs.current.forEach((el, opt) => {
          const r = el.getBoundingClientRect();
          if (
            e.clientX >= r.left - 8 && e.clientX <= r.right + 8 &&
            e.clientY >= r.top - 8 && e.clientY <= r.bottom + 8
          ) {
            found = opt;
          }
        });
        setHoverOpt(found);
      }
    };
    const onUp = (e: PointerEvent) => {
      const d = drag;
      setDrag(null);
      if (d.kind === "option" && d.opt) {
        const rect = targetRef.current?.getBoundingClientRect();
        let onTarget = false;
        if (rect) {
          const cx = rect.left + rect.width / 2;
          const cy = rect.top + rect.height / 2;
          onTarget = Math.hypot(e.clientX - cx, e.clientY - cy) < Math.min(rect.width, rect.height) / 2 + 24;
        }
        setHoverTarget(false);
        if (onTarget) {
          // ghost يتلاشى في مكان الإفلات
          setAbsorb({ kind: "option", label: d.opt, x: e.clientX, y: e.clientY, key: Date.now() });
          window.setTimeout(() => setAbsorb(null), 550);
          commitPick(d.opt);
        }
      } else {
        // سحب الهدف: إذا أُسقط على خيار فهو الإجابة المختارة
        let dropped: string | null = null;
        optRefs.current.forEach((el, opt) => {
          const r = el.getBoundingClientRect();
          if (
            e.clientX >= r.left - 8 && e.clientX <= r.right + 8 &&
            e.clientY >= r.top - 8 && e.clientY <= r.bottom + 8
          ) {
            dropped = opt;
          }
        });
        setHoverOpt(null);
        if (dropped && current) {
          // ghost للكلمة-الهدف يتلاشى في مكان الإفلات
          setAbsorb({ kind: "target", label: current.word.term, lang: current.word.lang, x: e.clientX, y: e.clientY, key: Date.now() });
          window.setTimeout(() => setAbsorb(null), 550);
          commitPick(dropped);
        }
      }
    };
    window.addEventListener("pointermove", onMove, { passive: false });
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drag]);

  const handleReplay = () => {
    // إعادة تحميل الكلمات لالتقاط آخر تحديثات الإتقان
    getAllWords().then((ws) => {
      setAllWords(ws);
      const rs = buildRounds(ws);
      setRounds(rs);
      setIdx(0);
      setPicked(null);
      setScore(0);
      setFinished(false);
      setVisible(rs[0]?.options ?? []);
    });
  };

  if (allWords.length < 2) {
    return (
      <Card className="p-8 text-center space-y-4 animate-fade-in">
        <p className="text-lg">{t("game.needWords")}</p>
        <Button onClick={onExit}>{t("btn.back")}</Button>
      </Card>
    );
  }

  if (finished) {
    const pct = Math.round((score / rounds.length) * 100);
    return (
      <Card className="p-8 text-center space-y-6 animate-scale-in shadow-card">
        <Trophy className="mx-auto h-16 w-16 text-secondary animate-float" />
        <div>
          <h2 className="text-3xl font-black">{t("game.finished")}</h2>
          <p className="mt-2 text-muted-foreground">
            {t("game.score", { s: score, t: rounds.length, p: pct })}
          </p>
        </div>
        <div className="flex justify-center gap-3">
          <Button variant="outline" onClick={onExit}>{t("btn.exit")}</Button>
          <Button onClick={handleReplay} className="gradient-primary text-primary-foreground gap-2">
            <RotateCcw className="h-4 w-4" /> {t("btn.replay")}
          </Button>
        </div>
      </Card>
    );
  }

  if (!current) return null;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={onExit} title={t("btn.exit")}>
          <X className="h-5 w-5" />
        </Button>
        <Progress value={progress} className="h-2 flex-1" />
        <span className="text-sm font-semibold tabular-nums">{idx + 1}/{rounds.length}</span>
      </div>

      {mode === "choice" ? (
        <>
          <div className="flex flex-col items-center gap-4">
            <div
              key={current.word.id}
              className="relative h-44 w-44 sm:h-52 sm:w-52 rounded-full flex flex-col items-center justify-center text-center shadow-card animate-scale-in gradient-primary text-primary-foreground"
            >
              <span className="text-[10px] uppercase tracking-widest opacity-80">{current.word.lang}</span>
              <span className="px-4 text-3xl sm:text-4xl font-black leading-tight" dir="ltr">
                {current.word.term}
              </span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => speak(current.word.term, current.word.lang)}
                className="mt-1 text-primary-foreground hover:bg-white/15"
              >
                <Volume2 className="h-5 w-5" />
              </Button>
            </div>
            <p className="text-muted-foreground text-sm">{t("game.question")}</p>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            {current.options.map((opt, i) => {
              const isCorrect = picked && opt === current.correct;
              const isWrongPick = picked === opt && opt !== current.correct;
              const showCorrectHint = picked && picked !== current.correct && opt === current.correct;
              return (
                <button
                  key={opt}
                  onClick={() => commitPick(opt)}
                  disabled={!!picked}
                  style={{ animationDelay: `${i * 50}ms` }}
                  className={cn(
                    "rounded-2xl border-2 bg-card p-5 text-lg font-semibold transition-all animate-fade-in shadow-soft",
                    "hover:border-primary hover:-translate-y-0.5 hover:shadow-card",
                    "disabled:cursor-not-allowed",
                    isCorrect && "border-success bg-success/15 text-success animate-pop",
                    isWrongPick && "border-destructive bg-destructive/15 text-destructive animate-shake",
                    showCorrectHint && "border-success bg-success/10 text-success",
                    picked && !isCorrect && !isWrongPick && !showCorrectHint && "opacity-50"
                  )}
                >
                  {opt}
                </button>
              );
            })}
          </div>
        </>
      ) : (
        <DropsBoard
          key={current.word.id}
          term={current.word.term}
          lang={current.word.lang}
          options={visible}
          drag={drag}
          hoverTarget={hoverTarget}
          hoverOpt={hoverOpt}
          flash={flash}
          picked={picked}
          correct={current.correct}
          absorb={absorb}
          targetRef={targetRef}
          optRefs={optRefs}
          onPointerDownOpt={startDragOption}
          onPointerDownTarget={startDragTarget}
          onTapOpt={commitPick}
          onSpeak={() => speak(current.word.term, current.word.lang)}
          hint={t("drag.hint")}
        />
      )}
    </div>
  );
}

// ====================== لوحة على نمط Drops ======================
interface BoardProps {
  term: string;
  lang: string;
  options: string[];
  drag: DragState | null;
  hoverTarget: boolean;
  hoverOpt: string | null;
  flash: "ok" | "bad" | null;
  picked: string | null;
  correct: string;
  absorb: { kind: "option" | "target"; label: string; lang?: string; x: number; y: number; key: number } | null;
  targetRef: React.MutableRefObject<HTMLDivElement | null>;
  optRefs: React.MutableRefObject<Map<string, HTMLButtonElement>>;
  onPointerDownOpt: (opt: string, e: React.PointerEvent) => void;
  onPointerDownTarget: (e: React.PointerEvent) => void;
  onTapOpt: (opt: string) => void;
  onSpeak: () => void;
  hint: string;
}

function DropsBoard({
  term, lang, options, drag, hoverTarget, hoverOpt, flash, picked, correct, absorb,
  targetRef, optRefs, onPointerDownOpt, onPointerDownTarget, onTapOpt, onSpeak, hint
}: BoardProps) {
  // ترتيب الخيارات حول الكلمة في دائرة (نمط Drops)
  const positions = useMemo(() => {
    const n = options.length;
    return options.map((_, i) => {
      const angle = (i / Math.max(1, n)) * Math.PI * 2 - Math.PI / 2;
      const radius = 130; // px
      return { x: Math.cos(angle) * radius, y: Math.sin(angle) * radius };
    });
  }, [options]);

  const targetDragging = drag?.kind === "target";

  return (
    <div className="relative select-none" style={{ minHeight: 520 }}>
      <p className="text-center text-xs text-muted-foreground mb-6">{hint}</p>

      {/* المسرح: الكلمة في المنتصف والخيارات حولها */}
      <div className="relative mx-auto" style={{ width: 320, height: 380 }}>
        {/* الخيارات الموزعة دائرياً */}
        {options.map((opt, i) => {
          const pos = positions[i];
          const isBeingDragged = drag?.kind === "option" && drag.opt === opt;
          const isHover = hoverOpt === opt;
          const isCorrect = picked && opt === correct;
          const isWrong = picked === opt && opt !== correct;
          return (
            <button
              key={opt}
              ref={(el) => {
                if (el) optRefs.current.set(opt, el);
                else optRefs.current.delete(opt);
              }}
              onPointerDown={(e) => onPointerDownOpt(opt, e)}
              onClick={(e) => {
                // النقر السريع = اختيار مباشر (بدون سحب)
                const moved = drag != null;
                if (!moved) onTapOpt(opt);
              }}
              disabled={!!picked}
              className={cn(
                "absolute touch-none select-none",
                "h-20 w-20 sm:h-24 sm:w-24 rounded-full",
                "flex items-center justify-center text-center px-2 text-sm sm:text-base font-bold",
                "bg-card border-2 border-border shadow-soft transition-all duration-200",
                "hover:border-primary hover:shadow-card hover:scale-105",
                "active:scale-95 cursor-grab active:cursor-grabbing",
                "animate-scale-in",
                isBeingDragged && "opacity-0",
                absorb?.kind === "target" && hoverOpt === opt && "opacity-0",
                isHover && !picked && "ring-4 ring-primary/50 scale-110 border-primary",
                isCorrect && "border-success bg-success/15 text-success animate-pop",
                isWrong && "border-destructive bg-destructive/15 text-destructive animate-shake"
              )}
              style={{
                left: "50%",
                top: "50%",
                transform: `translate(calc(-50% + ${pos.x}px), calc(-50% + ${pos.y}px))`,
                animationDelay: `${i * 60}ms`,
                wordBreak: "break-word",
              }}
            >
              <span className="line-clamp-3">{opt}</span>
            </button>
          );
        })}

        {/* الكلمة-الهدف في المركز (قابلة للسحب أيضاً) */}
        <div
          ref={targetRef}
          onPointerDown={onPointerDownTarget}
          className={cn(
            "absolute h-36 w-36 sm:h-40 sm:w-40 rounded-full flex flex-col items-center justify-center text-center shadow-card transition-all touch-none",
            "gradient-primary text-primary-foreground cursor-grab active:cursor-grabbing",
            "animate-scale-in",
            hoverTarget && "ring-8 ring-primary/40 scale-110",
            flash === "ok" && "ring-8 ring-success/70 animate-pop",
            flash === "bad" && "ring-8 ring-destructive/70 animate-shake",
            targetDragging && "opacity-0",
            absorb?.kind === "target" && "opacity-0"
          )}
          style={{
            left: "50%",
            top: "50%",
            transform: "translate(-50%, -50%)",
          }}
        >
          <span className="text-[10px] uppercase tracking-widest opacity-80">{lang}</span>
          <span className="px-3 text-2xl sm:text-3xl font-black leading-tight" dir="ltr">
            {term}
          </span>
          <button
            onClick={(e) => { e.stopPropagation(); onSpeak(); }}
            onPointerDown={(e) => e.stopPropagation()}
            className="mt-1 rounded-full p-1.5 text-primary-foreground hover:bg-white/15"
            aria-label="speak"
          >
            <Volume2 className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* الفقاعة الطافية أثناء السحب */}
      {drag && drag.kind === "option" && (
        <div
          style={{
            position: "fixed",
            left: drag.x,
            top: drag.y,
            transform: "translate(-50%, -50%)",
            pointerEvents: "none",
            zIndex: 50,
          }}
          className="h-24 w-24 sm:h-28 sm:w-28 rounded-full bg-card border-2 border-primary shadow-glow flex items-center justify-center text-center font-bold text-sm sm:text-base px-3 animate-pop"
        >
          <span className="line-clamp-3">{drag.opt}</span>
        </div>
      )}
      {drag && drag.kind === "target" && (
        <div
          style={{
            position: "fixed",
            left: drag.x,
            top: drag.y,
            transform: "translate(-50%, -50%)",
            pointerEvents: "none",
            zIndex: 50,
          }}
          className="h-32 w-32 sm:h-36 sm:w-36 rounded-full gradient-primary text-primary-foreground border-2 border-primary shadow-glow flex flex-col items-center justify-center text-center font-black px-3 animate-pop"
        >
          <span className="text-[10px] uppercase tracking-widest opacity-80">{lang}</span>
          <span className="text-2xl leading-tight" dir="ltr">{term}</span>
        </div>
      )}

      {/* Ghost: يتلاشى في آخر مكان تم فيه الإفلات الناجح */}
      {absorb && (
        <div
          key={absorb.key}
          style={{
            position: "fixed",
            left: absorb.x,
            top: absorb.y,
            pointerEvents: "none",
            zIndex: 60,
          }}
          className={cn(
            "rounded-full border-2 shadow-glow flex flex-col items-center justify-center text-center font-bold px-3 animate-absorb",
            absorb.kind === "option"
              ? "h-24 w-24 sm:h-28 sm:w-28 bg-card border-primary text-sm sm:text-base"
              : "h-32 w-32 sm:h-36 sm:w-36 gradient-primary text-primary-foreground border-primary"
          )}
        >
          {absorb.kind === "target" && absorb.lang && (
            <span className="text-[10px] uppercase tracking-widest opacity-80">{absorb.lang}</span>
          )}
          <span className={cn(absorb.kind === "target" ? "text-2xl leading-tight font-black" : "line-clamp-3")} dir={absorb.kind === "target" ? "ltr" : undefined}>
            {absorb.label}
          </span>
        </div>
      )}
    </div>
  );
}
