// أزرار تبديل الوضع (داكن/فاتح) واللغة (عربي/إنجليزي) في الشريط العلوي
import { Moon, Sun, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "next-themes";
import { useI18n } from "@/lib/i18n";

export function HeaderControls() {
  const { theme, setTheme } = useTheme();
  const { lang, setLang, t } = useI18n();
  const isDark = theme === "dark";

  return (
    <div className="flex items-center gap-1">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setLang(lang === "ar" ? "en" : "ar")}
        title={t("lang.toggle")}
        aria-label={t("lang.toggle")}
        className="relative"
      >
        <Languages className="h-5 w-5" />
        <span className="absolute -bottom-0.5 -end-0.5 text-[9px] font-black bg-primary text-primary-foreground rounded px-1 leading-none py-0.5">
          {lang === "ar" ? "AR" : "EN"}
        </span>
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setTheme(isDark ? "light" : "dark")}
        title={t("theme.toggle")}
        aria-label={t("theme.toggle")}
      >
        {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
      </Button>
    </div>
  );
}
