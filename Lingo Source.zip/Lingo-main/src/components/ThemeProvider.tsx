// مزود الوضع الداكن/الفاتح باستخدام next-themes
import { ThemeProvider as NextThemes } from "next-themes";
import type { ReactNode } from "react";

export function ThemeProvider({ children }: { children: ReactNode }) {
  return (
    <NextThemes attribute="class" defaultTheme="light" enableSystem={false} storageKey="lingo-theme">
      {children}
    </NextThemes>
  );
}
