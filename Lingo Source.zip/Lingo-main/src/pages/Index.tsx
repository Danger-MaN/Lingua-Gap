import { useEffect, useState } from "react";
import { Sparkles, BookOpen, Gamepad2, MoveHorizontal } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AddWordDialog } from "@/components/AddWordDialog";
import { WordList } from "@/components/WordList";
import { GameScreen } from "@/components/GameScreen";
import { HeaderControls } from "@/components/HeaderControls";
import { getAllWords, seedIfEmpty, masteryOf, type Word } from "@/lib/db";
import { useI18n } from "@/lib/i18n";

type View = "home" | "library" | "game-choice" | "game-drag";

const Index = () => {
  const { t } = useI18n();
  const [view, setView] = useState<View>("home");
  const [refreshKey, setRefreshKey] = useState(0);
  const [words, setWords] = useState<Word[]>([]);

  const refresh = () => setRefreshKey((k) => k + 1);

  useEffect(() => { seedIfEmpty().then(refresh); }, []);
  useEffect(() => { getAllWords().then(setWords); }, [refreshKey]);

  const totalCorrect = words.reduce((s, w) => s + w.correctCount, 0);
  const totalAttempts = words.reduce((s, w) => s + w.correctCount + w.wrongCount, 0);
  const accuracy = totalAttempts ? Math.round((totalCorrect / totalAttempts) * 100) : 0;
  const masteredCount = words.filter((w) => masteryOf(w) >= 1).length;
  const avgMastery = words.length
    ? Math.round((words.reduce((s, w) => s + masteryOf(w), 0) / words.length) * 100)
    : 0;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 backdrop-blur-md bg-background/70 border-b border-border/50">
        <div className="container flex items-center justify-between py-3">
          <button
            onClick={() => setView("home")}
            aria-label={t("nav.home")}
            className="flex items-center gap-2 rounded-lg -m-1 p-1 hover:opacity-90 active:scale-95 transition"
          >
            <div className="h-9 w-9 rounded-xl gradient-primary flex items-center justify-center shadow-glow">
              <Sparkles className="h-5 w-5 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-black">{t("app.name")}</h1>
          </button>
          <HeaderControls />
        </div>
      </header>

      <main className="container py-6 max-w-3xl">
        {view === "home" && (
          <div className="space-y-6 animate-fade-in">
            <section className="text-center space-y-3 py-6">
              <h2 className="text-4xl sm:text-5xl font-black leading-tight">
                {t("hero.title1")}
                <span className="block bg-gradient-to-l from-primary to-accent bg-clip-text text-transparent">
                  {t("hero.title2")}
                </span>
              </h2>
              <p className="text-muted-foreground max-w-md mx-auto">{t("hero.subtitle")}</p>
            </section>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Card className="p-4 text-center shadow-soft">
                <div className="text-2xl font-black text-primary">{words.length}</div>
                <div className="text-xs text-muted-foreground mt-1">{t("stat.words")}</div>
              </Card>
              <Card className="p-4 text-center shadow-soft">
                <div className="text-2xl font-black text-success">{masteredCount}</div>
                <div className="text-xs text-muted-foreground mt-1">{t("stat.learned")}</div>
              </Card>
              <Card className="p-4 text-center shadow-soft">
                <div className="text-2xl font-black text-accent">{avgMastery}%</div>
                <div className="text-xs text-muted-foreground mt-1">{t("stat.mastery")}</div>
              </Card>
              <Card className="p-4 text-center shadow-soft">
                <div className="text-2xl font-black text-foreground">{accuracy}%</div>
                <div className="text-xs text-muted-foreground mt-1">{t("stat.accuracy")}</div>
              </Card>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <button
                onClick={() => setView("game-choice")}
                className="group rounded-3xl p-6 text-start gradient-primary text-primary-foreground shadow-card hover:shadow-glow transition-all hover:-translate-y-1"
              >
                <Gamepad2 className="h-8 w-8 mb-3 group-hover:animate-float" />
                <div className="text-xl font-black">{t("game.choice.title")}</div>
                <div className="text-sm opacity-90 mt-1">{t("game.choice.sub")}</div>
              </button>
              <button
                onClick={() => setView("game-drag")}
                className="group rounded-3xl p-6 text-start gradient-warm text-secondary-foreground shadow-card hover:shadow-glow transition-all hover:-translate-y-1"
              >
                <MoveHorizontal className="h-8 w-8 mb-3 group-hover:animate-float" />
                <div className="text-xl font-black">{t("game.drag.title")}</div>
                <div className="text-sm opacity-90 mt-1">{t("game.drag.sub")}</div>
              </button>
            </div>

            <Card className="p-5 shadow-soft">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-bold">{t("lib.title")}</h3>
                </div>
                <Button variant="outline" size="sm" onClick={() => setView("library")}>
                  {t("lib.manage")}
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                {t("lib.count", { n: words.length })}
              </p>
              <div className="mt-4">
                <AddWordDialog onAdded={refresh} />
              </div>
            </Card>
          </div>
        )}

        {view === "library" && (
          <div className="space-y-5 animate-fade-in">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-2xl font-black">{t("lib.title")}</h2>
              <AddWordDialog onAdded={refresh} />
            </div>
            <WordList refreshKey={refreshKey} onChanged={refresh} />
          </div>
        )}

        {(view === "game-choice" || view === "game-drag") && (
          <GameScreen mode={view === "game-drag" ? "drag" : "choice"} onExit={() => { refresh(); setView("home"); }} />
        )}
      </main>
    </div>
  );
};

export default Index;
